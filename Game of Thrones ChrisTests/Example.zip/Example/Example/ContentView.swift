
import SwiftUI

struct ContentView: View {
    @StateObject var netManager = NetManager()
    
    var body: some View {
        VStack {
            RoundedRectangle(cornerRadius: 15, style: .continuous)
                .frame(width: 100, height: 100)
                .foregroundColor(netManager.selectedObject)
            ColorSelections(netManager: netManager)
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct ColorSelections:View{
    var netManager: NetManager
    let colors: [Color] = [Color.red,Color.blue,Color.pink, Color.yellow, Color.gray, Color.green]
    var body: some View{
        VStack{
            Text("Scroll and Select")
            ScrollView(.horizontal) {
                HStack{
                    ForEach(colors, id:\.self) { singleColor in
                        Rectangle()
                            .frame(width: 60, height: 100)
                            .foregroundColor(singleColor)
                            .onTapGesture {
                                netManager.selectedObject = singleColor
                            }
                    }
                }
            }
            .padding()
        }
    }
}
