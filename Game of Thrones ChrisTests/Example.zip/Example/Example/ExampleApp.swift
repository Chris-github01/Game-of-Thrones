//
//  ExampleApp.swift
//  Example
//
//  Created by Pat on 2023/02/15.
//

import SwiftUI

@main
struct ExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
