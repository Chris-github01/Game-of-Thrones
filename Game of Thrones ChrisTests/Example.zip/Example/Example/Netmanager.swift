import Foundation
import SwiftUI


class NetManager: ObservableObject {
    @Published var selectedObject: Color = .black
}
